using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build.Reporting;
using System;
using System.IO;
using C = CrownGarden.MatchBoard.Cell;
using B = CrownGarden.MatchBoard;

public static class BuildGame
{
    static int assertions;
    static void Check(bool ok,string message)
    { assertions++; if(!ok) throw new Exception("RULE CHECK FAILED: "+message); }
    static B Fixture()
    {
        var b=new B(1,1);
        for(int y=0;y<8;y++) for(int x=0;x<8;x++) { b.Color[x,y]=(x+2*y)%5; b.Power[x,y]=0; b.Ice[x,y]=false; }
        return b;
    }
    public static void VerifyRules()
    {
        assertions=0;
        var b=Fixture();
        Check(b.FindMatches().cells.Count==0,"stable fixture");
        for(int x=0;x<4;x++) b.Color[x,0]=3;
        var m=b.FindMatches(new C(2,0));
        Check(m.cells.Count==4,"four jewels matched");
        Check(m.creates.Count==1 && m.creates[new C(2,0)]==1,"horizontal four creates row rocket at swap destination");
        b.Ice[2,0]=true; b.Clear(m,1);
        Check(b.Power[2,0]==1 && b.Color[2,0]==3,"created rocket survives clearing");
        Check(!b.Ice[2,0] && b.IceCleared==1,"ice under new rocket clears");
        b.Collapse();
        for(int x=0;x<8;x++) for(int y=0;y<8;y++) Check(b.Color[x,y]>=0,"collapse fills every hole");
        b=Fixture(); for(int y=0;y<5;y++) b.Color[0,y]=2;
        m=b.FindMatches(new C(0,2));
        Check(m.creates[new C(0,2)]==4,"five creates rainbow");
        b=Fixture();
        for(int x=1;x<=3;x++) b.Color[x,2]=0;
        for(int y=1;y<=3;y++) b.Color[2,y]=0;
        m=b.FindMatches(new C(2,2));
        Check(m.creates[new C(2,2)]==3,"T creates bomb");
        b=Fixture(); b.Power[3,3]=1; b.Power[6,3]=2;
        m=b.Activate(new C(3,3));
        Check(m.cells.Count==15,"rocket chains into perpendicular rocket");
        b=Fixture(); b.Power[3,3]=3;
        Check(b.Activate(new C(3,3)).cells.Count==9,"bomb clears 3 by 3");
        b=Fixture(); b.Power[0,0]=4; b.Power[1,0]=4;
        Check(b.Combine(new C(0,0),new C(1,0)).cells.Count==64,"double rainbow clears full board");
        b=Fixture(); b.Power[3,3]=3; b.Power[4,3]=3;
        Check(b.Combine(new C(3,3),new C(4,3)).cells.Count==49,"double bomb clears 7 by 7");
        b=Fixture(); b.Power[0,0]=4;
        m=b.Combine(new C(0,0),new C(1,0));
        for(int y=0;y<8;y++) for(int x=0;x<8;x++)
            if(b.Color[x,y]==b.Color[1,0]) Check(m.cells.Contains(new C(x,y)),"rainbow clears target color");
        // Simulate real legal swaps, chain reactions and gravity over varied deterministic boards.
        int swaps=0,cascades=0;
        for(int seed=0;seed<100;seed++)
        {
            b=new B(seed,4);
            Check(b.FindMatches().cells.Count==0,"no opening matches, seed "+seed);
            for(int move=0;move<45;move++)
            {
                C a,c;
                if(!b.FindMove(out a,out c)) b.Shuffle();
                Check(b.FindMove(out a,out c),"playable board");
                if(a.Equals(c)) m=b.Activate(a);
                else
                {
                    b.Swap(a,c);
                    m=(b.Power[a.x,a.y]>0 || b.Power[c.x,c.y]>0)?b.Combine(a,c):b.FindMatches(c);
                }
                Check(m.cells.Count>0,"hint always yields a valid action");
                int guard=0;
                while(m.cells.Count>0)
                {
                    Check(++guard<200,"cascade terminates");
                    b.Expand(m); b.Clear(m,guard); b.Collapse(); m=b.FindMatches(); cascades++;
                }
                Check(b.Score>0,"clearing awards score"); swaps++;
            }
        }
        string report="PASS: "+assertions+" assertions, "+swaps+" legal actions, "+cascades+" cascade steps.\nChecks: stable starts, hints, rockets, bombs, rainbow, combinations, ice, power creation, gravity and refill.\n";
        Directory.CreateDirectory("Verification"); File.WriteAllText("Verification/rules.txt",report); Debug.Log(report);
    }
    public static void Build()
    {
        VerifyRules();
        var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
        var camera=new GameObject("Camera").AddComponent<Camera>(); camera.backgroundColor=new Color(.03f,.06f,.14f); camera.clearFlags=CameraClearFlags.SolidColor;
        camera.gameObject.AddComponent<AudioListener>();
        new GameObject("Crown Garden").AddComponent<CrownGarden.CrownGame>();
        Directory.CreateDirectory("Assets/Scenes"); EditorSceneManager.SaveScene(scene,"Assets/Scenes/CrownGarden.unity");
        PlayerSettings.companyName="Offline Prototypes"; PlayerSettings.productName="Crown Garden";
        PlayerSettings.defaultScreenWidth=1200; PlayerSettings.defaultScreenHeight=860;
        PlayerSettings.fullScreenMode=FullScreenMode.Windowed; PlayerSettings.resizableWindow=true;
        PlayerSettings.runInBackground=true; PlayerSettings.colorSpace=ColorSpace.Gamma;
        PlayerSettings.SetScriptingBackend(BuildTargetGroup.Standalone,ScriptingImplementation.Mono2x);
        EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene("Assets/Scenes/CrownGarden.unity",true)};
        var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions { scenes=new[]{"Assets/Scenes/CrownGarden.unity"},locationPathName="Build/Windows/CrownGarden.exe",target=BuildTarget.StandaloneWindows64,options=BuildOptions.None });
        if(report.summary.result!=BuildResult.Succeeded) throw new Exception("Build failed: "+report.summary.result);
        Debug.Log("BUILD SUCCESS: "+report.summary.totalSize+" bytes");
    }
}
