using System;
using System.Collections.Generic;
using System.Linq;

namespace CrownGarden
{
    // Independent rules model. Coordinates use a top-left origin.
    public sealed class MatchBoard
    {
        public const int N = 8, Colors = 5;
        public readonly int[,] Color = new int[N,N];
        public readonly int[,] Power = new int[N,N]; // 1: row, 2: column, 3: bomb, 4: rainbow
        public readonly bool[,] Ice = new bool[N,N];
        public readonly int[] Collected = new int[Colors];
        public int IceCleared, Score;
        readonly Random random;
        public struct Cell : IEquatable<Cell>
        {
            public int x,y;
            public Cell(int x,int y) { this.x=x; this.y=y; }
            public bool Equals(Cell c) { return x==c.x && y==c.y; }
            public override bool Equals(object o) { return o is Cell && Equals((Cell)o); }
            public override int GetHashCode() { return x+N*y; }
        }
        public sealed class Match
        {
            public HashSet<Cell> cells = new HashSet<Cell>();
            public Dictionary<Cell,int> creates = new Dictionary<Cell,int>();
        }
        public MatchBoard(int seed,int level)
        {
            random=new Random(seed);
            FillStable();
            if(level>1)
                for(int y=2;y<6;y++) for(int x=2;x<6;x++)
                    Ice[x,y]=level>=4 || (x+y)%2==0;
        }
        public static bool Inside(int x,int y) { return x>=0 && y>=0 && x<N && y<N; }
        public static bool Adjacent(Cell a,Cell b) { return Math.Abs(a.x-b.x)+Math.Abs(a.y-b.y)==1; }
        public void Swap(Cell a,Cell b)
        {
            int c=Color[a.x,a.y]; Color[a.x,a.y]=Color[b.x,b.y]; Color[b.x,b.y]=c;
            c=Power[a.x,a.y]; Power[a.x,a.y]=Power[b.x,b.y]; Power[b.x,b.y]=c;
        }
        void FillStable()
        {
            for(int y=0;y<N;y++) for(int x=0;x<N;x++)
            {
                int c;
                do { c=random.Next(Colors); }
                while((x>=2 && Color[x-1,y]==c && Color[x-2,y]==c) ||
                      (y>=2 && Color[x,y-1]==c && Color[x,y-2]==c));
                Color[x,y]=c; Power[x,y]=0;
            }
            Cell a,b;
            if(!FindMove(out a,out b)) FillStable();
        }
        public Match FindMatches(Cell? preferred=null)
        {
            var runs=new List<List<Cell>>();
            for(int y=0;y<N;y++)
                for(int x=0;x<N;)
                {
                    int end=x+1;
                    while(end<N && Color[x,y]>=0 && Color[end,y]==Color[x,y]) end++;
                    if(end-x>=3) { var run=new List<Cell>(); for(int k=x;k<end;k++) run.Add(new Cell(k,y)); runs.Add(run); }
                    x=end;
                }
            for(int x=0;x<N;x++)
                for(int y=0;y<N;)
                {
                    int end=y+1;
                    while(end<N && Color[x,y]>=0 && Color[x,end]==Color[x,y]) end++;
                    if(end-y>=3) { var run=new List<Cell>(); for(int k=y;k<end;k++) run.Add(new Cell(x,k)); runs.Add(run); }
                    y=end;
                }
            var result=new Match();
            foreach(var run in runs) result.cells.UnionWith(run);
            // Merge intersecting runs so T/L shapes produce one bomb, rather than two rockets.
            while(runs.Count>0)
            {
                var group=new HashSet<Cell>(runs[0]);
                var members=new List<List<Cell>>{runs[0]}; runs.RemoveAt(0);
                bool changed=true;
                while(changed)
                {
                    changed=false;
                    for(int i=runs.Count-1;i>=0;i--)
                        if(runs[i].Any(c=>group.Contains(c)))
                        { group.UnionWith(runs[i]); members.Add(runs[i]); runs.RemoveAt(i); changed=true; }
                }
                int type=members.Any(r=>r.Count>=5)?4:members.Count>1?3:members[0].Count==4?(members[0][0].y==members[0][1].y?1:2):0;
                if(type>0)
                {
                    Cell at=preferred.HasValue && group.Contains(preferred.Value)?preferred.Value:group.OrderBy(c=>c.y*N+c.x).ElementAt(group.Count/2);
                    if(Power[at.x,at.y]!=0) at=group.FirstOrDefault(c=>Power[c.x,c.y]==0);
                    if(group.Contains(at) && Power[at.x,at.y]==0) result.creates[at]=type;
                }
            }
            return result;
        }
        public Match Activate(Cell a,int rainbowColor=-1)
        {
            var m=new Match(); m.cells.Add(a);
            Expand(m,rainbowColor);
            return m;
        }
        public Match Combine(Cell a,Cell b)
        {
            var m=new Match();
            int pa=Power[a.x,a.y],pb=Power[b.x,b.y];
            if(pa==4 && pb==4)
                for(int y=0;y<N;y++) for(int x=0;x<N;x++) m.cells.Add(new Cell(x,y));
            else if(pa==4 || pb==4)
            {
                Cell target=pa==4?b:a;
                int color=Color[target.x,target.y],type=Power[target.x,target.y];
                for(int y=0;y<N;y++) for(int x=0;x<N;x++)
                    if(Color[x,y]==color) { m.cells.Add(new Cell(x,y)); if(type>0) Power[x,y]=type; }
            }
            else if(pa>0 && pb>0)
            {
                int radius=(pa==3 && pb==3)?3:1;
                for(int y=0;y<N;y++) for(int x=0;x<N;x++)
                    if((pa==3 && pb==3)?(Math.Abs(x-b.x)<=radius && Math.Abs(y-b.y)<=radius):
                       (pa==3 || pb==3)?(Math.Abs(x-b.x)<=radius || Math.Abs(y-b.y)<=radius):(x==b.x || y==b.y)) m.cells.Add(new Cell(x,y));
            }
            m.cells.Add(a); m.cells.Add(b); Expand(m,Color[b.x,b.y]);
            return m;
        }
        public void Expand(Match m,int rainbowColor=-1)
        {
            var queue=new Queue<Cell>(m.cells);
            var visited=new HashSet<Cell>();
            while(queue.Count>0)
            {
                var c=queue.Dequeue(); if(!visited.Add(c)) continue;
                int p=Power[c.x,c.y];
                if(p==0) continue;
                int target=rainbowColor>=0?rainbowColor:MostCommonColor();
                for(int y=0;y<N;y++) for(int x=0;x<N;x++)
                    if((p==1 && y==c.y) || (p==2 && x==c.x) ||
                       (p==3 && Math.Abs(x-c.x)<=1 && Math.Abs(y-c.y)<=1) || (p==4 && Color[x,y]==target))
                    { var next=new Cell(x,y); if(m.cells.Add(next)) queue.Enqueue(next); }
            }
        }
        int MostCommonColor()
        {
            int[] counts=new int[Colors];
            foreach(int c in Color) if(c>=0) counts[c]++;
            return Array.IndexOf(counts,counts.Max());
        }
        public void Clear(Match m,int combo)
        {
            foreach(var c in m.cells)
            {
                int color=Color[c.x,c.y];
                if(color<0) continue;
                Collected[color]++; Score+=60*Math.Max(1,combo);
                if(Ice[c.x,c.y]) { Ice[c.x,c.y]=false; IceCleared++; Score+=100; }
                if(m.creates.ContainsKey(c)) Power[c.x,c.y]=m.creates[c];
                else { Color[c.x,c.y]=-1; Power[c.x,c.y]=0; }
            }
        }
        // Returns original row per destination; negative origins represent incoming pieces.
        public int[,] Collapse()
        {
            int[,] from=new int[N,N];
            for(int x=0;x<N;x++)
            {
                int dest=N-1;
                for(int y=N-1;y>=0;y--) if(Color[x,y]>=0)
                {
                    Color[x,dest]=Color[x,y]; Power[x,dest]=Power[x,y]; from[x,dest]=y; dest--;
                }
                int empty=dest+1;
                for(int y=dest;y>=0;y--) { Color[x,y]=random.Next(Colors); Power[x,y]=0; from[x,y]=y-empty; }
            }
            return from;
        }
        public bool FindMove(out Cell a,out Cell b)
        {
            for(int y=0;y<N;y++) for(int x=0;x<N;x++)
            {
                a=new Cell(x,y);
                if(Power[x,y]>0) { b=a; return true; }
                for(int d=0;d<2;d++)
                {
                    b=new Cell(x+(d==0?1:0),y+(d==1?1:0));
                    if(!Inside(b.x,b.y)) continue;
                    Swap(a,b); bool valid=FindMatches().cells.Count>0; Swap(a,b);
                    if(valid) return true;
                }
            }
            a=b=new Cell(-1,-1); return false;
        }
        public void Shuffle() { FillStable(); }
        public int RemainingIce { get { int count=0; foreach(bool ice in Ice) if(ice) count++; return count; } }
    }
}
