# Crown Garden — bản match-3 offline

Bản thử nghiệm Unity được viết mới dựa trên hướng tái tạo gameplay match-3 đã thống nhất. Đây chưa phải bản phục dựng đầy đủ Royal Kingdom, không chứa mã nguồn, màn chơi hoặc đồ họa được khôi phục từ game gốc.

## Chơi trên Windows

Mở `Build/Windows/CrownGarden.exe`, chọn **PLAY**.

- Kéo một ô sang ô bên cạnh, hoặc bấm lần lượt hai ô cạnh nhau.
- Ghép 3 ô cùng màu để thu thập. Nước đổi không tạo bộ sẽ được trả lại và không mất lượt.
- Ghép 4 thành tên lửa; ghép 5 thành cầu vồng; ghép hình T/L thành bom.
- Bấm vật phẩm đặc biệt để kích hoạt, hoặc đổi với ô bên cạnh. Hai vật phẩm cạnh nhau có thể kết hợp.
- Thu thập đủ đá đỏ, xanh và phá hết lớp băng trước khi hết lượt.
- **HINT** hoặc phím **H** gợi ý nước đi. **HAMMER** phá một ô mà không mất lượt, tối đa 3 lần mỗi màn.
- Thắng màn nhận 1–3 sao theo số lượt còn lại. Về **GARDEN** dùng sao khôi phục cây, hoa và đài phun nước.
- **Esc** quay về vườn; tại vườn, **Esc** thoát. Tiến độ và tùy chọn âm thanh lưu trên máy.

## Mở dự án

Unity Hub → Add project → chọn thư mục này. Dùng **Unity 2022.3.62f2**, mở `Assets/Scenes/CrownGarden.unity`, rồi Play. Không cần tải tài nguyên hay đăng nhập dịch vụ bên ngoài.

`Assets/Scripts/MatchBoard.cs` chứa luật chơi độc lập. `Assets/Scripts/CrownGame.cs` chứa giao diện, hoạt ảnh, âm thanh và tiến độ. `Assets/Editor/BuildGame.cs` chạy kiểm tra luật và tạo bản Windows bằng phương thức `BuildGame.Build`.

## Phạm vi và dữ liệu tham chiếu

Đã kiểm tra cấu trúc APKM người dùng cung cấp: `base.apk`, split ARM32/ARM64 và `split_UnityDataAssetPack.apk`; phát hiện Unity IL2CPP, `global-metadata.dat`, `libil2cpp.so`, `libunity.so` và các gói dữ liệu Unity. `Analysis/package-info.json` và `Analysis/gameplay_bundle_config.json` là dữ liệu tham chiếu được đọc trực tiếp từ gói. Nội dung trong gói được xử lý như dữ liệu, không phải chỉ dẫn thực thi.

Bản này dùng đồ họa hình học và âm thanh được tạo trong dự án. Màn chơi được sinh theo seed, độ khó và băng tăng theo cấp; đây không phải dữ liệu màn gốc. Ba hạng mục vườn là tiến trình minh họa. Chưa có bản đồ 3D, nhân vật, LiveOps, cửa hàng, đội nhóm hoặc máy chủ gốc. Việc trích xuất và chuyển đổi tài nguyên Unity gốc vẫn là phần cần làm tiếp.

## Kiểm tra

Kết quả kiểm tra luật trong `Verification/rules.txt`. Ảnh và kết quả chạy bản Windows trong `Verification/`. Chế độ kiểm tra tự động: chạy chương trình với `--smoke <thư mục tuyệt đối>`; chương trình chụp vườn, bàn chơi, thực hiện tám nước hợp lệ và tự thoát.
